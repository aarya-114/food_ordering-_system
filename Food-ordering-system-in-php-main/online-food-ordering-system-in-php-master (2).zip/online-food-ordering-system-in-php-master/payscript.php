<?php
    $apiKey = "rzp_test_Yu2ztcOv6oLYm3";
    $total_amount_in_paise = $_POST["item_total"] * 100;
?>

<script src="https://code.jquery.com/jquery-3.5.0.min.js"></script>

<form id="paymentForm" action="http://localhost/online-food-ordering-system-in-php-master/your_orders.php" method="">
    <script
        src="https://checkout.razorpay.com/v1/checkout.js"
        data-key="<?php echo $apiKey; ?>"
        data-amount="<?php echo $total_amount_in_paise; ?>"
        data-currency="INR"
        data-buttontext="Pay with Razorpay"
        data-name="VLOUNGE"
        data-description="<?php echo $_POST['title']; ?>"
        data-image=""
        data-prefill.name="<?php echo $_POST['name']; ?>"
        data-prefill.email="<?php echo $_POST['email']; ?>"
        data-theme.color="#FF3300"
    ></script>
</form>

<script>
    $(document).ready(function(){
        $('#paymentForm').submit(function(e) {
            e.preventDefault(); // Prevent default form submission
            var form = $(this);
            $.ajax({
                type: form.attr('method'),
                url: form.attr('action'),
                data: form.serialize(),
                success: function(response) {
                    // Redirect to your_orders.php
                    window.location.href = "http://localhost/online-food-ordering-system-in-php-master/your_orders.php";
                }
            });
        });
    });
</script>

<?php
    // Execute the provided query after the form submission
    session_start();
    include("connection/connect.php");

    if($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit'])) {
        foreach ($_SESSION["cart_item"] as $item) {
            $SQL = "INSERT INTO users_orders(u_id, title, quantity, price) VALUES('".$_SESSION["user_id"]."','".$item["title"]."','".$item["quantity"]."','".$item["price"]."')";
            mysqli_query($db, $SQL);
        }
        $success = "Thank you! Your order has been placed successfully!";
    }
?>

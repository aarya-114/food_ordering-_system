<?php
include("../connection/connect.php");

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['orderId'])) {
    $orderId = $_POST['orderId'];
    
    // Update the status to 'Delivered'
    $query = "UPDATE users_orders SET status = 'closed' WHERE o_id = $orderId";
    $result = mysqli_query($db, $query);

    if ($result) {
        echo "Status updated successfully.";
    } else {
        echo "Error updating status: " . mysqli_error($db);
    }
} else {
    echo "Invalid request.";
}
?>

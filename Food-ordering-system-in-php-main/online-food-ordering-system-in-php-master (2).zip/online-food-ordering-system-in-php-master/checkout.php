<!DOCTYPE html>
<html lang="en">
<?php
include("connection/connect.php");
include_once 'product-action.php';
error_reporting(0);
session_start();
if(empty($_SESSION["user_id"]))
{
	header('location:login.php');
}
else{

										  
	    foreach ($_SESSION["cart_item"] as $item)
	    {
											
		$item_total += ($item["price"]*$item["quantity"]);
												
		if($_POST['submit'])
		{
			header('location:payscript.php?u_id=' . $_SESSION["user_id"] . '&title=' . $item["title"] . '&quantity=' . $item["quantity"] . '&price=' . $item["price"]);
            
            exit;
        }
	    }
    }
?>


<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="#">
    <title>Starter Template for Bootstrap</title>
    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/animsition.min.css" rel="stylesheet">
    <link href="css/animate.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="css/style.css" rel="stylesheet"> 
</head>
<body>
    
    <div class="site-wrapper">
        <!--header starts-->
        <header id="header" class="header-scroll top-header headrom">
            <!-- .navbar -->
            <nav class="navbar navbar-dark">
                <div class="container">
                    <button class="navbar-toggler hidden-lg-up" type="button" data-toggle="collapse" data-target="#mainNavbarCollapse">&#9776;</button>
                    <a class="navbar-brand" href="index.html"> <img class="img-rounded" src="images/logo1 (2).png" alt=""> </a>
                    <div class="collapse navbar-toggleable-md  float-lg-right" id="mainNavbarCollapse">
                        <ul class="nav navbar-nav">
                            <li class="nav-item"> <a class="nav-link active" href="index.php">Home <span class="sr-only">(current)</span></a> </li>
                            <li class="nav-item"> <a class="nav-link active" href="restaurants.php">Restaurants <span class="sr-only"></span></a> </li>
                            
							<?php
						if(empty($_SESSION["user_id"]))
							{
								echo '<li class="nav-item"><a href="login.php" class="nav-link active">login</a> </li>
							  <li class="nav-item"><a href="registration.php" class="nav-link active">signup</a> </li>';
							}
						else
							{
									
									
										echo  '<li class="nav-item"><a href="your_orders.php" class="nav-link active">your orders</a> </li>';
									echo  '<li class="nav-item"><a href="logout.php" class="nav-link active">logout</a> </li>';
							}

						?>
							 
                        </ul>
                    </div>
                </div>
            </nav>
            <!-- /.navbar -->
        </header>
        <div class="page-wrapper">
            <div class="top-links">
                <div class="container">
                    <ul class="row links">
                      
                        <li class="col-xs-12 col-sm-4 link-item"><span>1</span><a href="restaurants.php">Choose Restaurant</a></li>
                        <li class="col-xs-12 col-sm-4 link-item "><span>2</span><a href="#">Pick Your favorite food</a></li>
                        <li class="col-xs-12 col-sm-4 link-item active" ><span>3</span><a href="checkout.php">Order and Pay online</a></li>
                    </ul>
                </div>
            </div>
			
                <div class="container">
                 
					   <span style="color:green;">
								<?php echo $success; ?>
										</span>
					
                </div>
            
			
			
				  
            <div class="container m-t-30">
			<form action="payscript.php" method="post">
                <div class="widget clearfix">
                    
                    <div class="widget-body">
                        <form method="post" action="payscript.php">
                            <div class="row">
                                
                                <div class="col-sm-12">
                                    <div class="cart-totals margin-b-20">
                                        <div class="cart-totals-title">
                                            <h4>Cart Summary</h4> </div>
                                        <div class="cart-totals-fields">
										
                                            <table class="table">
                                                <tbody>
                                            
                                                    
                                                
                                                        <tr>
                                                            <td>Cart Subtotal</td>
                                                            <td> <?php echo "Rs.".$item_total; ?></td>
                                                        </tr>
                                                        
                                                        <tr>
                                                            <td class="text-color"><strong>Total</strong></td>
                                                            <td class="text-color" name="item_total"><strong> <?php echo "Rs.".$item_total; ?></strong></td>
                                                        </tr>
                                                        
                                                </tbody>
												
												
												
												
                                            </table>
                                        </div>
                                    </div>
                                    <!--cart summary-->
                                    <div class="payment-option">
                                        <ul class=" list-unstyled">
                                            
                                            <li>
                                                <label class="custom-control custom-radio  m-b-10">
                                                    <input name="mod"  type="radio" value="razorpay" class="custom-control-input"> <span class="custom-control-indicator"></span> <span class="custom-control-description">Razorpay <img src="" alt="" width="90"></span> </label>
                                            </li>
                                            <li>
                                                <input type="hidden" name="item_total" value="<?=$item_total; ?>"> <br>
                                                <input type="hidden" name="user_id" value="<?=$user_id; ?>" > <br>
                                                <input type="text" name="name" placeholder="Your full name" required> <br>
                                                <input type="email" name="email" placeholder="Your email ID" required> <br>
                                                <input type="text" name="mobile" placeholder="Your Phone Number" required> <br>
                                            </li>
                                        </ul>
                                        <p class="text-xs-center"> <input type="submit" onclick="return confirm('Are you sure?');" name="submit"  class="btn btn-outline-success btn-block" value="Order now"> </p>
                                    </div>
									</form>
                                </div>
                            </div>
                       
                    </div>
                </div>
				 </form>
            </div>
            
            
                        <footer class="footer">
                            <div class="container">
                                <!-- top footer statrs -->
                                <div class="row top-footer">
                                    <div class="col-xs-12 col-sm-3 footer-logo-block color-gray">
                                        <a href="#"> <img src="images/logo2 (2).png" alt="Footer logo"> </a> 
                                    </div>
                                </div>
                            </div>    
                        </footer>
                        <!-- end:Footer -->


                <!-- Bootstrap core JavaScript
                ================================================== -->
                <script src="js/jquery.min.js"></script>
                <script src="js/tether.min.js"></script>
                <script src="js/bootstrap.min.js"></script>
                <script src="js/animsition.min.js"></script>
                <script src="js/bootstrap-slider.min.js"></script>
                <script src="js/jquery.isotope.min.js"></script>
                <script src="js/headroom.js"></script>
                <script src="js/foodpicky.min.js"></script>
            </body>

        </html>
         